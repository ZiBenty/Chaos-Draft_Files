import random
import json

code = "AP03"

global commons
commons = []
global shprint
shprint = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global ulti
ulti = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Short Print"):
        shprint.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Ultimate Rare"):
        ulti.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    random.shuffle(commons)
    random.shuffle(shprint)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(ulti)

#Returns a pack of the set
def generate_pack():
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    global pack
    shuffle()
    y = 0
    rarity = random.randint(1,9999)
    com = 0
    if rarity in range(1,556):
        pack[ulti[0]] = "Ultimate Rare"
    else:
        pack[supers[0]] = "Super Rare"
    for i in range(0,2):
        rarity = random.randint(1,9999)
        if rarity in range(1,323) and shprint != []:
            pack[shprint[y]] = "Short Print"
            y += 1
        else:
                pack[commons[i+com]] = "Common"
            
generate_pack()