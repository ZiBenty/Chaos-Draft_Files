import random
import json

code = "LCKC"

global ultra
ultra = []
global secret
secret = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global ultra
    global secret
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if("Secret Rare" in rarity):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global ultra
    global secret
    random.shuffle(ultra)
    random.shuffle(secret)

#Returns a pack of the set
def generate_pack():
    global ultra
    global secret
    global pack
    shuffle()
    for i in range(0, 6):
        pack[ultra[i]] = "Ultra Rare"
    for i in range(0, 4):
        pack[secret[i]] = "Secret Rare"
            
generate_pack()