import random
import json

code = "GLD1"

global commons
commons = []
global gold
gold = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global gold
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Gold Rare"):
        gold.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global gold
    random.shuffle(commons)
    random.shuffle(gold)

#Returns a pack of the set
def generate_pack():
    global commons
    global gold
    global pack
    shuffle()
    for i in range(0, 22):
            pack[commons[i]] = "Common"
    for i in range(0, 3):
        pack[gold[i]] = "Gold Rare"
            
generate_pack()