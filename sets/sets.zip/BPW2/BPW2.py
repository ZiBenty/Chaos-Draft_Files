import random
import json

code = "BPW2"

global commons
commons = []
global supers
supers = []
global ultra
ultra = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global supers
    global ultra
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global supers
    global ultra
    random.shuffle(commons)
    random.shuffle(supers)
    random.shuffle(ultra)

#Returns a pack of the set
def generate_pack():
    global commons
    global supers
    global ultra
    global pack
    shuffle()
    for i in range(0, 9):
        pack[commons[i]] = "Common"
    for i in range(0, 6):
        pack[supers[i]] = "Super Rare"
    pack[ultra[0]] = "Ultra Rare"

generate_pack()