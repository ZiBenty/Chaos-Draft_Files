import random
import json

code = "BLAR"

global ultra
ultra = []
global secret
secret = []
global star
star = []
global shiny
shiny = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global ultra
    global secret
    global star
    global shiny
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if("Secret Rare" in rarity and "10000" not in rarity):
        secret.append(cardid)
    if(rarity == "Starlight Rare"):
        star.append(cardid)
    if("10000" in rarity):
        shiny.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global ultra
    global secret
    global star
    global shiny
    random.shuffle(ultra)
    random.shuffle(secret)
    random.shuffle(star)
    random.shuffle(shiny)

#Returns a pack of the set
def generate_pack():
    global ultra
    global secret
    global star
    global shiny
    global pack
    shuffle()
    rarity = random.randint(1, 9999)
    rarityslot = None
    rarityname = ""
    if rarity in range(1, 138):
        rarityslot = shiny[0]
        rarityname = "10000 Secret Rare"
    elif rarity in range(138, 554):
        rarityslot = star[0]
        rarityname = "Starlight Rare"
    if rarityslot is not None:
        for i in range(0, 3):
            pack[ultra[i]] = "Ultra Rare"
        pack[rarityslot] = rarityname
    else:
        for i in range(0, 4):
            pack[ultra[i]] = "Ultra Rare"
    pack[secret[0]] = "Secret Rare"
            
generate_pack()