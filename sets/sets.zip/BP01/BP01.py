import random
import json
import DBC

code = "BP01"

global commons
commons = []
global rares
rares = []
global starfoil
starfoil = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global starfoil
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Starfoil Rare"):
        starfoil.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

with open("sets/" + code + "/@" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global starfoil
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(starfoil)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global starfoil
    global pack
    shuffle()
    dec = DBC.DBdecoder()
    pack[starfoil[0]] = "Starfoil Rare"
    rarity = random.randint(1,100)
    #36% probability of finding xyz
    if rarity in range(1, 37):
        for c in rares:
            if "XYZ" in dec.DBdecode("id", c, "type"):
                pack[c] = "Rare"
                break
    else:
        for c in rares:
            if "XYZ" not in dec.DBdecode("id", c, "type"):
                pack[c] = "Rare"
                break
    slots = [True, False, False]
    i = 0
    y = 0
    for c in commons:
        y += 1
        f = open("structs/dictsetcodes.txt", "r")
        contents = f.read()
        setcodesdictionary = json.loads(contents)
        f.close()
        f = open("sets/" + code + "/" + code + ".txt", "r")
        contents = f.read()
        packCards = json.loads(contents)
        f.close()
        sets = setcodesdictionary[c]
        for s in sets:
            if code in s and packCards[c] == "Common":
                setnum = int(s.split("-EN",1)[1])
                if (setnum >= 56 and setnum <= 110) and slots[0]:
                    pack[c] = "Common"
                    slots[0] = False
                    i += 1
                    slots[1] = True
                elif (setnum >= 111 and setnum <= 170) and slots[1]:
                    pack[c] = "Common"
                    slots[1] = False
                    i += 1
                    slots[2] = True
                elif (setnum >= 171 and setnum <= 220) and slots[2]:
                    pack[c] = "Common"
                    slots[2] = False
                    i += 1
                    break
        if i == len(slots):
            break

generate_pack()