import random
import json

code = "GFP2"

global ultra
ultra = []
global ghost
ghost = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global ultra
    global ghost
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Ghost Rare"):
        ghost.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global ultra
    global ghost
    random.shuffle(ultra)
    random.shuffle(ghost)

#Returns a pack of the set
def generate_pack():
    global ultra
    global ghost
    global pack
    shuffle()
    rarity = random.randint(1, 9999)
    if rarity in range(1, 66):
        for i in range(0, 4):
            pack[ultra[i]] = "Ultra Rare"
        pack[ghost[i]] = "Ghost Rare"
    else:
        for i in range(0, 5):
            pack[ultra[i]] = "Ultra Rare"

generate_pack()