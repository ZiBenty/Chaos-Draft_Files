import random
import json

code = "LDS1"

global commons
commons = []
global ultra
ultra = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global ultra
    global commons
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Common"):
        commons.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global ultra
    global commons
    random.shuffle(ultra)
    random.shuffle(commons)

#Returns a pack of the set
def generate_pack():
    global ultra
    global commons
    global pack
    shuffle()
    for i in range(0, 15):
        pack[commons[i]] = "Common"
    for i in range(0, 3):
        pack[ultra[i]] = "Ultra Rare"
            
generate_pack()