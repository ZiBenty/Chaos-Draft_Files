import random
import json

code = "MAZE"

global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global collc
collc = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global rares
    global supers
    global ultra
    global collc
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Collector's Rare"):
        collc.append(cardid)


with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global rares
    global supers
    global ultra
    global collc
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(collc)

#Returns a pack of the set
def generate_pack():
    global rares
    global supers
    global ultra
    global collc
    global pack
    shuffle()
    rarity = random.randint(1,9999)
    rarityslot = None
    rarityname = ""
    if rarity in range(1,323):
        rarityslot = collc[0]
        rarityname = "Collector's Rare"
    elif rarity in range(323,1989):
        rarityslot = ultra[0]
        rarityname = "Ultra Rare"
    else:
        rarityslot = supers[0]
        rarityname = "Super Rare"
    for i in range(0,6):
        pack[rares[i]] = "Rare"
    pack[rarityslot] = rarityname
            
generate_pack()