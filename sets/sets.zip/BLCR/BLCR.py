import random
import json

code = "BLCR"

global ultra
ultra = []
global secret
secret = []
global star
star = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global ultra
    global secret
    global star
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if("Secret Rare" in rarity):
        secret.append(cardid)
    if(rarity == "Starlight Rare"):
        star.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global ultra
    global secret
    global star
    random.shuffle(ultra)
    random.shuffle(secret)
    random.shuffle(star)

#Returns a pack of the set
def generate_pack():
    global ultra
    global secret
    global star
    global pack
    shuffle()
    rarity = random.randint(1, 9999)
    for i in range(0, 4):
        rarity = random.randint(1, 9999)
        if rarity in range(1, 416):
            pack[star[i]] = "Starlight Rare"
        else:
            pack[ultra[i]] = "Ultra Rare"
    pack[secret[0]] = "Secret Rare"
            
generate_pack()