import random
import json

code = "MAGO"

global rares
rares = []
global gold
gold = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global gold
    global rares
    if(rarity == "Rare"):
        rares.append(cardid)
    if("Gold" in rarity):
        gold.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global gold
    global rares
    random.shuffle(gold)
    random.shuffle(rares)

#Returns a pack of the set
def generate_pack():
    global gold
    global rares
    global pack
    shuffle()
    for i in range(0, 3):
        pack[rares[i]] = "Rare"
    for i in range(0, 2):
        pack[gold[i]] = "Premium Gold Rare"
            
generate_pack()