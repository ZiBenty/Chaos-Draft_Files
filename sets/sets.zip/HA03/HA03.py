import random
import json

code = "HA03"

global supers
supers = []
global secret
secret = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global supers
    global secret
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Secret Rare"):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global supers
    global secret
    random.shuffle(supers)
    random.shuffle(secret)

#Returns a pack of the set
def generate_pack():
    global supers
    global secret
    global pack
    shuffle()
    for i in range(0, 4):
        pack[supers[i]] = "Super Rare"
    pack[secret[0]] = "Secret Rare"
            
generate_pack()