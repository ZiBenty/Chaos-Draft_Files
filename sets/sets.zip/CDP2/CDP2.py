import random
import json

code = "CDP2"

global commons
commons = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global secret
secret = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global supers
    global ultra
    global secret
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Secret Rare"):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global supers
    global ultra
    global secret
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(secret)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global supers
    global ultra
    global secret
    global pack
    shuffle()
    rarityslots = []
    raritynames = []
    for i in range(1):
        rarity = random.randint(1,9999)
        if rarity in range(1,833):
            rarityslots.append(secret[i])
            raritynames.append("Secret Rare")
        elif rarity in range(834,2499):
            rarityslots.append(ultra[i])
            raritynames.append("Ultra Rare")
        else:
            rarityslots.append(supers[i])
            raritynames.append("Super Rare")
    for i in range(10):
        pack[commons[i]] = "Common"
    for i in range(4):
        pack[rares[i]] = "Rare"
    for i in range(1):
        pack[rarityslots[i]] = raritynames[i]

generate_pack()