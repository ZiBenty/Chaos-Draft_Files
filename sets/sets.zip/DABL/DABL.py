import random
import json

code = "DABL"

global commons
commons = []
global shprint
shprint = []
global supers
supers = []
global ultra
ultra = []
global secret
secret = []
global star
star = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global shprint
    global supers
    global ultra
    global secret
    global star
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Short Print"):
        shprint.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Secret Rare"):
        secret.append(cardid)
    if(rarity == "Starlight Rare"):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global shprint
    global supers
    global ultra
    global secret
    global star
    random.shuffle(commons)
    random.shuffle(shprint)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(secret)
    random.shuffle(star)

#Returns a pack of the set
def generate_pack():
    global commons
    global shprint
    global supers
    global ultra
    global secret
    global star
    global pack
    shuffle()
    y = 0
    rarity = random.randint(1,9999)
    rarityslot = None
    rarityname = ""
    if rarity in range(1,209):
        rarityslot = star[0]
        rarityname = "Starlight Rare"
    elif rarity in range(209,1042):
        rarityslot = secret[0]
        rarityname = "Secret Rare"
    elif rarity in range(1042,2708):
        rarityslot = ultra[0]
        rarityname = "Ultra Rare"
    else:
        rarityslot = supers[0]
        rarityname = "Super Rare"
    for i in range(0,8):
        rarity = random.randint(1,9999)
        if rarity in range(1,323) and shprint != []:
            pack[shprint[y]] = "Short Print"
            y += 1
        else:
            pack[commons[i]] = "Common"
    pack[rarityslot] = rarityname

generate_pack()