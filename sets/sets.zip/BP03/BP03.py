import random
import json

code = "BP03"

global commons
commons = []
global rares
rares = []
global shatterfoil
shatterfoil = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global shatterfoil
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Shatterfoil Rare"):
        shatterfoil.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

with open("sets/" + code + "/@" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global shatterfoil
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(shatterfoil)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global shatterfoil
    global pack
    shuffle()
    pack[shatterfoil[0]] = "Shatterfoil Rare"
    pack[rares[0]] = "Rare"
    for i in range(0, 3):
        pack[commons[i]] = "Common"

generate_pack()