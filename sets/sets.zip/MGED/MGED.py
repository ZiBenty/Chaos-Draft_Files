import random
import json

code = "MGED"

global rares
rares = []
global gold
gold = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global rares
    global gold
    if("Gold Rare" in rarity):
        gold.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global rares
    global gold
    random.shuffle(rares)
    random.shuffle(gold)

#Returns a pack of the set
def generate_pack():
    global rares
    global gold
    global pack
    shuffle()
    for i in range(0, 5):
        pack[rares[i]] = "Rare"
    for i in range(0, 2):
        pack[gold[i]] = "Premium Gold Rare"
            
generate_pack()