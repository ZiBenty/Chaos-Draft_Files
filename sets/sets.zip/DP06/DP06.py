import random
import json

code = "DP06"

global commons
commons = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global supers
    global ultra
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global supers
    global ultra
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global supers
    global ultra
    global pack
    shuffle()
    rarity = random.randint(1,9999)
    rarityslot = None
    rarityname = ""
    if rarity in range(1, 417):
        rarityslot = ultra[0]
        rarityname = "Ultra Rare"
    elif rarity in range(417, 2083):
        rarityslot = supers[0]
        rarityname = "Super Rare"
    rng = None
    if rarityslot is not None:
        rng = range(0,3)
    else:
        rng = range(0,4)
    for i in rng:
        pack[commons[i]] = "Common"
    if rarityslot is not None:
        pack[rares[0]] = "Rare"
        pack[rarityslot] = rarityname
    else:
        pack[rares[0]] = "Rare"
            
generate_pack()