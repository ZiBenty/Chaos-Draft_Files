import random
import json
import DBC

code = "DR04"

global commons
commons = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global secret
secret = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global supers
    global ultra
    global secret
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Secret Rare"):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global supers
    global ultra
    global secret
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(secret)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global supers
    global ultra
    global secret
    global pack
    shuffle()
    packlayout = ["Trap", "Trap", "Trap", "Spell", "Spell", "Spell",
                  "Monster", "Monster", "Monster", "Monster", "Monster", "Monster"]
    rarityslots = random.randint(1, 2)
    commonind = 0
    rarityind = 0
    blacklist = []
    dec = DBC.DBdecoder()
    for i in range(0, 12):
        rarity = random.randint(1,9999)
        rslot = random.randint(1,100)
        if rslot in range(1,20) and rarity in range(1, 833) and rarityslots > 0:
            for c in ultra:
                if packlayout[i] in dec.DBdecode("id", c, "type") and c not in blacklist:
                    pack[c] = "Ultra Rare"
                    blacklist.append(c)
                    rarityslots -= 1
                    rarityind += 1
                    break
        elif rslot in range(1,20) and rarity in range(833, 2499) and rarityslots > 0:
            for c in supers:
                if packlayout[i] in dec.DBdecode("id", c, "type") and c not in blacklist:
                    pack[c] = "Super Rare"
                    blacklist.append(c)
                    rarityslots -= 1
                    rarityind += 1
                    break
        elif (rslot in range(1,20) or i in range(10,12)) and rarityslots > 0:
            for c in rares:
                if packlayout[i] in dec.DBdecode("id", c, "type") and c not in blacklist:
                    pack[c] = "Rare"
                    blacklist.append(c)
                    rarityslots -= 1
                    rarityind += 1
                    break
        else:
            for c in commons:
                if packlayout[i] in dec.DBdecode("id", c, "type") and c not in blacklist:
                    pack[c] = "Common"
                    blacklist.append(c)
                    commonind += 1
                    break
            
generate_pack()