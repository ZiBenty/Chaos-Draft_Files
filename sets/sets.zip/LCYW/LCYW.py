import random
import json

code = "LCYW"

global commons
commons = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global secret
secret = []


global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global supers
    global ultra
    global secret
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if("Secret Rare" in rarity):
        secret.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global supers
    global ultra
    global secret
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(secret)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global supers
    global ultra
    global secret
    global pack
    shuffle()
    for i in range(0, 5):
        pack[commons[i]] = "Common"
    pack[rares[0]] = "Rare"
    pack[supers[0]] = "Super Rare"
    pack[ultra[0]] = "Ultra Rare"
    pack[secret[0]] = "Secret Rare"
            
generate_pack()