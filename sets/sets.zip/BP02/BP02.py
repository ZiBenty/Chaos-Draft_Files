import random
import json

code = "BP02"

global commons
commons = []
global rares
rares = []
global mosaic
mosaic = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global rares
    global mosaic
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Mosaic Rare"):
        mosaic.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

with open("sets/" + code + "/@" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global rares
    global mosaic
    random.shuffle(commons)
    random.shuffle(rares)
    random.shuffle(mosaic)

#Returns a pack of the set
def generate_pack():
    global commons
    global rares
    global mosaic
    global pack
    shuffle()
    pack[mosaic[0]] = "Mosaic Rare"
    pack[rares[0]] = "Rare"
    for i in range(0, 3):
        pack[commons[i]] = "Common"

generate_pack()