import random
import json

code = "GLD5"

global commons
commons = []
global gold
gold = []
global ghosts
ghosts = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global gold
    global ghosts
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Gold Rare"):
        gold.append(cardid)
    if("Ghost" in rarity):
        ghosts.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global gold
    global ghosts
    random.shuffle(commons)
    random.shuffle(gold)
    random.shuffle(ghosts)

#Returns a pack of the set
def generate_pack():
    global commons
    global gold
    global ghosts
    global pack
    shuffle()
    for i in range(0, 22):
            pack[commons[i]] = "Common"
    if(ghosts != []):
        for i in range(0, 2):
            pack[gold[i]] = "Gold Rare"
        pack[ghosts[0]] = "Ghost/Gold Rare"
    else:
        for i in range(0, 3):
            pack[gold[i]] = "Gold Rare"
            
generate_pack()