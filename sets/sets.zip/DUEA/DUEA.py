import random
import json

code = "DUEA"

global commons
commons = []
global shprint
shprint = []
global rares
rares = []
global supers
supers = []
global ultra
ultra = []
global ulti
ulti = []
global secret
secret = []
global ghost
ghost = []

global pack
pack = {}

#Adds a card of the given name to the given rarity:
def add_card(rarity, cardid):
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    global secret
    global ghost
    if(rarity == "Common"):
        commons.append(cardid)
    if(rarity == "Short Print"):
        shprint.append(cardid)
    if(rarity == "Rare"):
        rares.append(cardid)
    if(rarity == "Super Rare"):
        supers.append(cardid)
    if(rarity == "Ultra Rare"):
        ultra.append(cardid)
    if(rarity == "Ultimate Rare"):
        ulti.append(cardid)
    if(rarity == "Secret Rare"):
        secret.append(cardid)
    if (rarity == "Ghost Rare"):
        ghost.append(cardid)

with open("sets/" + code + "/" + code + ".txt", "r") as f:
    contents = f.read()
    packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
    for c in packCards:
        add_card(packCards[c], c)

try:
    with open("sets/" + code + "/@" + code + ".txt", "r") as f:
        contents = f.read()
        packCards = json.loads(contents)  # Loads the dictionary with card code as key, string rarity in pack as value
        for c in packCards:
            add_card(packCards[c], c)
except:
    pass
        
    
#Shuffles all the rarities in one simple call
def shuffle():
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    global secret
    global ghost
    random.shuffle(commons)
    random.shuffle(shprint)
    random.shuffle(rares)
    random.shuffle(supers)
    random.shuffle(ultra)
    random.shuffle(ulti)
    random.shuffle(secret)
    random.shuffle(ghost)

#Returns a pack of the set
def generate_pack():
    global commons
    global shprint
    global rares
    global supers
    global ultra
    global ulti
    global secret
    global ghost
    global pack
    shuffle()
    y = 0
    rarity = random.randint(1,9999)
    rarityslot = None
    rarityname = ""
    if rarity in range(1,35):
        if ghost != []:
            rarityslot = ghost[0]
            rarityname = "Ghost Rare"
        else:
            rarity = random.randint(36,9999)
    if rarity in range(35,357):
        rarityslot = ulti[0]
        rarityname = "Ultimate Rare"
    if rarity in range(357,773):
        rarityslot = secret[0]
        rarityname = "Secret Rare"
    elif rarity in range(773,1606):
        rarityslot = ultra[0]
        rarityname = "Ultra Rare"
    elif rarity in range(1606,3272):
        rarityslot = supers[0]
        rarityname = "Super Rare"
    rng = None
    if rarityslot is not None:
        rng = range(0,7)
    else:
        rng = range(0,8)
    for i in rng:
        rarity = random.randint(1,9999)
        if rarity in range(1,323) and shprint != []:
            pack[shprint[y]] = "Short Print"
            y += 1
        else:
            pack[commons[i]] = "Common"
    if rarityslot is not None:
        pack[rares[0]] = "Rare"
        pack[rarityslot] = rarityname
    else:
        pack[rares[0]] = "Rare"

generate_pack()